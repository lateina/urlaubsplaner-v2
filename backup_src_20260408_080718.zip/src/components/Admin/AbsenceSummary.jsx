import React, { useMemo } from 'react';

const AbsenceSummary = ({ employees = [], absences = {}, status = {} }) => {
  console.log('AbsenceSummary Render:', { empCount: employees.length, absCount: Object.keys(absences).length });

  const formatRange = (start, end) => {
    const fmt = d => { 
      if (!d) return '';
      const parts = d.split('-');
      if (parts.length < 3) return d;
      const [y, m, day] = parts; 
      return `${day}.${m}.${y}`; 
    };

    
    const datePart = (start.date === end.date) ? fmt(start.date) : `${fmt(start.date)} - ${fmt(end.date)}`;
    const typeMap = { 
      'U': 'Urlaub', 
      'V': 'Urlaub', 
      'FZA': 'Freizeitausgleich',
      'D': 'Dienstreise', 
      'F': 'Fortbildung', 
      'T': 'Sonstiges', 
      'S': 'Sonstiges' 
    };
    const t = typeMap[start.val?.type] || 'Abwesend';
    return `${datePart} (${t}${start.val?.text ? `: ${start.val.text}` : ''})`;
  };

  const fullSummary = useMemo(() => {
    const list = [];
    if (!employees || employees.length === 0) return 'Keine Mitarbeiterdaten vorhanden.';

    const sortedEmployees = [...employees].sort((a, b) => (a.name || '').localeCompare(b.name || ''));

    sortedEmployees.forEach(emp => {
      if (emp.id === 'admin' || emp.id === 'sekretariat' || emp.active === false || !absences[emp.id]) return;
      
      const empAbsences = absences[emp.id];
      const entries = Object.keys(empAbsences)
        .sort()
        .map(d => ({ date: d, val: empAbsences[d] }))
        .filter(entry => entry.val && entry.val.status !== 'rejected');
      
      if (entries.length === 0) return;
      
      const ranges = []; 
      let rStart = entries[0], rEnd = entries[0];
      
      for (let i = 1; i < entries.length; i++) {
        const curr = entries[i];
        const prevDate = new Date(rEnd.date);
        prevDate.setDate(prevDate.getDate() + 1);
        const nextDayStr = prevDate.toISOString().split('T')[0];
        
        if (nextDayStr === curr.date && rEnd.val?.type === curr.val?.type && (rEnd.val?.text || '') === (curr.val?.text || '')) { 
          rEnd = curr; 
        } else { 
          ranges.push(formatRange(rStart, rEnd)); 
          rStart = curr; rEnd = curr; 
        }
      }
      ranges.push(formatRange(rStart, rEnd));
      list.push(`${emp.name}: ${ranges.join(', ')}`);
    });
    return list.length > 0 ? list.join('\n') : 'Keine Abwesenheiten gefunden.';
  }, [employees, absences]);

  const statusSummary = useMemo(() => {
    const list = [];
    if (!employees || employees.length === 0) return '';
    const sortedEmployees = [...employees].sort((a, b) => (a.name || '').localeCompare(b.name || ''));
    
    sortedEmployees.forEach(emp => {
      if (emp.id === 'admin' || emp.id === 'sekretariat' || emp.active === false) return;
      if (status && status[emp.id]) {
        list.push(`Mitarbeiter ${emp.name} fertig`);
      }
    });
    return list.join('\n');
  }, [employees, status]);

  if (employees.length === 0) return <div style={{ padding: '40px', textAlign: 'center', border: '2px dashed #e2e8f0', borderRadius: '12px' }}>Warte auf Mitarbeiterdaten...</div>;

  return (
    <div className="glass" style={{ 
      display: 'flex', 
      flexDirection: 'column', 
      gap: '30px', 
      padding: '30px',
      margin: '20px',
      borderRadius: '24px',
      minHeight: '800px',
      background: 'rgba(255, 255, 255, 0.45)',
      border: '1px solid var(--glass-border)'
    }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
           <h3 style={{ margin: 0, fontSize: '1.25rem', fontWeight: 900, color: '#0f172a' }}>Zusammenfassung</h3>
        </div>
        <textarea 
          readOnly 
          value={fullSummary} 
          placeholder="Generiere Report..."
          style={{ 
            height: '450px', 
            width: '100%', 
            padding: '24px', 
            borderRadius: '16px', 
            border: '1px solid var(--glass-border)', 
            fontFamily: 'inherit', 
            fontSize: '1rem', 
            lineHeight: '1.6', 
            resize: 'vertical', 
            background: 'rgba(255, 255, 255, 0.65)', 
            color: '#1e293b',
            boxShadow: 'inset 0 2px 8px rgba(0,0,0,0.03)',
            backdropFilter: 'blur(5px)',
            outline: 'none',
            boxSizing: 'border-box'
          }} 
        />
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        <h3 style={{ margin: 0, fontSize: '1.25rem', fontWeight: 900, color: '#0f172a' }}>Status Report</h3>
        <textarea 
          readOnly 
          value={statusSummary || 'Keine Fertigmeldungen vorhanden.'} 
          style={{ 
            height: '150px', 
            width: '100%', 
            padding: '20px', 
            borderRadius: '16px', 
            border: '1px solid var(--glass-border)', 
            fontFamily: 'inherit', 
            fontSize: '1rem', 
            resize: 'none', 
            background: 'rgba(255, 255, 255, 0.65)', 
            color: '#1e293b',
            boxShadow: 'inset 0 2px 8px rgba(0,0,0,0.03)',
            backdropFilter: 'blur(5px)',
            outline: 'none',
            boxSizing: 'border-box'
          }} 
        />
      </div>
    </div>
  );
};

export default AbsenceSummary;
